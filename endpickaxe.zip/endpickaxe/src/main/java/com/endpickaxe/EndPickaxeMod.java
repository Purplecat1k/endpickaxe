package com.endpickaxe;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.EndPortalFrameBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.UnbreakableComponent;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterials;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.condition.RandomChanceLootCondition;
import net.minecraft.loot.entry.EmptyEntry;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.EnchantWithLevelsLootFunction;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.loot.provider.number.UniformLootNumberProvider;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.List;

public class EndPickaxeMod implements ModInitializer {
    public static final String MOD_ID = "endpickaxe";

    public static final Item END_PICKAXE = Registry.register(
        Registries.ITEM,
        Identifier.of(MOD_ID, "end_pickaxe"),
        new EndPickaxeItem(ToolMaterials.NETHERITE, new Item.Settings()
            .maxDamage(2031)
            .component(DataComponentTypes.UNBREAKABLE, new UnbreakableComponent(false))
            .component(DataComponentTypes.LORE, new LoreComponent(List.of(
                Text.literal("\u00A75Can break End Portal Frames"),
                Text.literal("\u00A77Breaks all portal blocks when frame is broken"),
                Text.literal("\u00A77Drops Eye of Ender if frame had one")
            ))))
    );

    private static final Identifier END_CITY_LOOT = Identifier.of("minecraft", "chests/end_city_treasure");
    private static final Identifier END_SHIP_LOOT = Identifier.of("minecraft", "chests/end_ship_treasure");

    @Override
    public void onInitialize() {
        System.out.println("End Pickaxe Mod initialized!");

        // Обробник ламання рамок порталу
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (state.isOf(Blocks.END_PORTAL_FRAME)) {
                ItemStack mainHand = player.getMainHandStack();

                // В креативі тільки з End Pickaxe
                if (player.isCreative()) {
                    if (mainHand.isOf(END_PICKAXE)) {
                        handleEndPortalFrameBreak(world, pos, state, player);
                        return false; // Вручну обробили
                    }
                    return false; // Не дозволяємо ламати без End Pickaxe
                }

                // В виживанні тільки з End Pickaxe
                if (!mainHand.isOf(END_PICKAXE)) {
                    return false;
                }

                handleEndPortalFrameBreak(world, pos, state, player);
                return false; // Вручну обробили
            }
            return true;
        });

        // Модифікація лут таблиць
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
            if (!source.isBuiltin()) return;

            Identifier id = key.getValue();

            if (id.equals(END_CITY_LOOT)) {
                // 2% шанс (1 з 50)
                LootPool.Builder pool = LootPool.builder()
                    .rolls(ConstantLootNumberProvider.create(1))
                    .with(ItemEntry.builder(END_PICKAXE)
                        .weight(1)
                        .apply(EnchantWithLevelsLootFunction.builder(UniformLootNumberProvider.create(20, 30))))
                    .with(EmptyEntry.builder().weight(49));
                tableBuilder.pool(pool);
            }

            if (id.equals(END_SHIP_LOOT)) {
                // 5% шанс (1 з 20)
                LootPool.Builder pool = LootPool.builder()
                    .rolls(ConstantLootNumberProvider.create(1))
                    .with(ItemEntry.builder(END_PICKAXE)
                        .weight(1)
                        .apply(EnchantWithLevelsLootFunction.builder(UniformLootNumberProvider.create(20, 30))))
                    .with(EmptyEntry.builder().weight(19));
                tableBuilder.pool(pool);
            }
        });
    }

    private void handleEndPortalFrameBreak(World world, BlockPos pos, BlockState state, PlayerEntity player) {
        if (world.isClient) return;

        boolean hasEye = state.get(EndPortalFrameBlock.EYE);

        // Видаляємо блок (без звичайного дропу)
        world.breakBlock(pos, false, player);

        // Якщо є око — випадає
        if (hasEye) {
            ItemEntity eyeEntity = new ItemEntity(
                world, 
                pos.getX() + 0.5, 
                pos.getY() + 0.5, 
                pos.getZ() + 0.5,
                new ItemStack(Items.ENDER_EYE)
            );
            eyeEntity.setPickupDelay(10);
            world.spawnEntity(eyeEntity);
        }

        // Перевіряємо чи портал активний
        boolean isPortalActive = isPortalActive(world, pos);

        if (isPortalActive) {
            // Знищуємо всі блоки порталу
            destroyPortalBlocks(world, pos);
        }

        // Зменшуємо міцність кирки (тільки в виживанні)
        if (!player.isCreative()) {
            ItemStack pickaxe = player.getMainHandStack();
            if (pickaxe.isOf(END_PICKAXE)) {
                pickaxe.damage(1, player);
            }
        }
    }

    private boolean isPortalActive(World world, BlockPos framePos) {
        // Перевіряємо сусідні блоки на наявність END_PORTAL
        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -1; dy <= 2; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    BlockPos checkPos = framePos.add(dx, dy, dz);
                    if (world.getBlockState(checkPos).isOf(Blocks.END_PORTAL)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void destroyPortalBlocks(World world, BlockPos center) {
        // Знаходимо всі блоки порталу в радіусі 3 блоків
        for (int x = -3; x <= 3; x++) {
            for (int y = -1; y <= 2; y++) {
                for (int z = -3; z <= 3; z++) {
                    BlockPos checkPos = center.add(x, y, z);
                    BlockState state = world.getBlockState(checkPos);
                    if (state.isOf(Blocks.END_PORTAL)) {
                        world.breakBlock(checkPos, false);
                    }
                }
            }
        }
    }
}
