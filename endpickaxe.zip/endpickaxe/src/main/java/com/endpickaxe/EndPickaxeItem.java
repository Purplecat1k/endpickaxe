package com.endpickaxe;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ToolMaterial;

public class EndPickaxeItem extends PickaxeItem {

    public EndPickaxeItem(ToolMaterial material, Settings settings) {
        super(material, settings);
    }

    @Override
    public boolean isSuitableFor(BlockState state) {
        // Дозволяємо копати END_PORTAL_FRAME
        if (state.isOf(Blocks.END_PORTAL_FRAME)) {
            return true;
        }
        return super.isSuitableFor(state);
    }

    @Override
    public float getMiningSpeed(ItemStack stack, BlockState state) {
        // Дуже висока швидкість для END_PORTAL_FRAME
        if (state.isOf(Blocks.END_PORTAL_FRAME)) {
            return 15.0f;
        }
        return super.getMiningSpeed(stack, state);
    }
}
